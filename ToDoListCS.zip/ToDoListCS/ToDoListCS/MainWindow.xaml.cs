﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace TodoList
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<TaskItem> Tasks { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Tasks = new ObservableCollection<TaskItem>();
            TasksListView.ItemsSource = Tasks;
            TaskDatePicker.SelectedDate = DateTime.Today;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TaskTextBox.Text))
            {
                MessageBox.Show("Введите описание задачи!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (TaskDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату для задачи!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Получаем выбранный приоритет
            ComboBoxItem selectedPriorityItem = PriorityComboBox.SelectedItem as ComboBoxItem;
            string priorityTag = selectedPriorityItem?.Tag?.ToString();
            string priority = "Средний"; // значение по умолчанию

            if (priorityTag == "Low") priority = "Низкий";
            else if (priorityTag == "Medium") priority = "Средний";
            else if (priorityTag == "High") priority = "Высокий";

            Tasks.Add(new TaskItem
            {
                Description = TaskTextBox.Text,
                DueDate = TaskDatePicker.SelectedDate.Value,
                Priority = priority
            });

            // Сброс полей после добавления
            TaskTextBox.Clear();
            TaskDatePicker.SelectedDate = DateTime.Today;
            PriorityComboBox.SelectedIndex = 1; // Средний приоритет по умолчанию
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (TasksListView.SelectedItem != null)
            {
                Tasks.Remove((TaskItem)TasksListView.SelectedItem);
            }
            else
            {
                MessageBox.Show("Выберите задачу для удаления!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }

    public class TaskItem
    {
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string Priority { get; set; }
    }
}