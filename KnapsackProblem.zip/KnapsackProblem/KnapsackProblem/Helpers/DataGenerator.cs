﻿using System;
using System.Collections.Generic;

namespace KnapsackProblem.Helpers
{
    public static class DataGenerator
    {
        private static readonly Random random = new Random();

        public static List<Item> GenerateItems(int count)
        {
            var items = new List<Item>();
            for (int i = 0; i < count; i++)
            {
                int weight = random.Next(1, 20);
                int value = random.Next(1, 50);
                items.Add(new Item(weight, value));
            }
            return items;
        }
    }

    public class Item
    {
        public int Weight { get; }
        public int Value { get; }
        public double ValuePerWeight => (double)Value / Weight;

        public Item(int weight, int value)
        {
            Weight = weight;
            Value = value;
        }

        public override string ToString() => $"Вес: {Weight}, Ценность: {Value}";
    }

    public class KnapsackResult
    {
        public int MaxValue { get; set; }
        public List<Item> SelectedItems { get; set; }
        public string Time { get; set; }

        public override string ToString()
        {
            return $"Максимальная ценность: {MaxValue}\n" +
                   $"Выбранные предметы: {string.Join(", ", SelectedItems)}";
        }
    }
}