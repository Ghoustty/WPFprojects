﻿using KnapsackProblem.Algorithms;
using KnapsackProblem.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Input;
using System.Windows;

namespace KnapsackProblem.ViewModels
{
    public class KnapsackViewModel : INotifyPropertyChanged
    {
        private int _itemCount = 10;
        private int _knapsackCapacity = 50;
        private string _executionLog = "";

        public event PropertyChangedEventHandler PropertyChanged;

        public ObservableCollection<Item> Items { get; } = new ObservableCollection<Item>();
        public ICommand GenerateDataCommand { get; }
        public ICommand SolveCommand { get; }
        public ICommand TestPerformanceCommand { get; }

        public KnapsackResult DpResult { get; private set; }
        public KnapsackResult GreedyResult { get; private set; }

        public int ItemCount
        {
            get => _itemCount;
            set { _itemCount = value; OnPropertyChanged(nameof(ItemCount)); }
        }

        public int KnapsackCapacity
        {
            get => _knapsackCapacity;
            set { _knapsackCapacity = value; OnPropertyChanged(nameof(KnapsackCapacity)); }
        }

        public string ExecutionLog
        {
            get => _executionLog;
            set { _executionLog = value; OnPropertyChanged(nameof(ExecutionLog)); }
        }

        public KnapsackViewModel()
        {
            GenerateDataCommand = new RelayCommand(_ => GenerateData());
            SolveCommand = new RelayCommand(_ => Solve());
            TestPerformanceCommand = new RelayCommand(_ => TestPerformance());
            GenerateData();
        }

        private void GenerateData()
        {
            Items.Clear();
            var items = DataGenerator.GenerateItems(ItemCount);
            foreach (var item in items)
                Items.Add(item);

            AddLog($"Сгенерировано {ItemCount} предметов. Вместимость рюкзака: {KnapsackCapacity}");
        }

        private void Solve()
        {
            if (Items.Count == 0)
            {
                MessageBox.Show("Сначала сгенерируйте предметы!");
                return;
            }

            // Решение методом динамического программирования
            var dpSolver = new DynamicProgrammingSolver();
            DpResult = MeasurePerformance(() => dpSolver.Solve(Items, KnapsackCapacity), "Динамическое программирование");
            OnPropertyChanged(nameof(DpResult));

            // Решение жадным алгоритмом
            var greedySolver = new GreedySolver();
            GreedyResult = MeasurePerformance(() => greedySolver.Solve(Items, KnapsackCapacity), "Жадный алгоритм");
            OnPropertyChanged(nameof(GreedyResult));
        }

        private KnapsackResult MeasurePerformance(Func<KnapsackResult> algorithm, string algorithmName)
        {
            var stopwatch = Stopwatch.StartNew();
            var result = algorithm();
            stopwatch.Stop();

            result.Time = $"Время выполнения: {stopwatch.Elapsed.TotalMilliseconds} мс";
            AddLog($"{algorithmName}: Максимальная ценность = {result.MaxValue}, Время = {stopwatch.Elapsed.TotalMilliseconds} мс");

            return result;
        }

        private void TestPerformance()
        {
            AddLog("Начато тестирование производительности...");

            var testCases = new[] { 10, 20, 50, 100, 200, 500 };
            var dpTimes = new List<double>();
            var greedyTimes = new List<double>();

            foreach (var count in testCases)
            {
                var items = DataGenerator.GenerateItems(count);
                var capacity = count * 5;

                var dpSolver = new DynamicProgrammingSolver();
                var dpStopwatch = Stopwatch.StartNew();
                dpSolver.Solve(items, capacity);
                dpStopwatch.Stop();
                dpTimes.Add(dpStopwatch.Elapsed.TotalMilliseconds);

                var greedySolver = new GreedySolver();
                var greedyStopwatch = Stopwatch.StartNew();
                greedySolver.Solve(items, capacity);
                greedyStopwatch.Stop();
                greedyTimes.Add(greedyStopwatch.Elapsed.TotalMilliseconds);

                AddLog($"n={count}: DP={dpStopwatch.Elapsed.TotalMilliseconds} мс, Greedy={greedyStopwatch.Elapsed.TotalMilliseconds} мс");
            }

            
            AddLog("Тестирование производительности завершено. Графики построены.");
        }
        


        private void AddLog(string message)
        {
            ExecutionLog += $"{DateTime.Now:HH:mm:ss} - {message}\n";
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }


        public bool CanExecute(object parameter) => _canExecute == null || _canExecute(parameter);
        public void Execute(object parameter) => _execute(parameter);
    }
}