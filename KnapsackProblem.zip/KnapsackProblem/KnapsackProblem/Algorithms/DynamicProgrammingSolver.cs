﻿using KnapsackProblem.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KnapsackProblem.Algorithms
{
    public class DynamicProgrammingSolver
    {
        public KnapsackResult Solve(IEnumerable<Item> items, int capacity)
        {
            var itemList = items.ToList();
            int n = itemList.Count;

            // Создаем таблицу для хранения промежуточных результатов
            int[,] dp = new int[n + 1, capacity + 1];

            // Заполняем таблицу dp
            for (int i = 1; i <= n; i++)
            {
                var currentItem = itemList[i - 1];
                for (int w = 1; w <= capacity; w++)
                {
                    if (currentItem.Weight <= w)
                    {
                        dp[i, w] = Math.Max(
                            dp[i - 1, w],
                            dp[i - 1, w - currentItem.Weight] + currentItem.Value);
                    }
                    else
                    {
                        dp[i, w] = dp[i - 1, w];
                    }
                }
            }

            // Восстанавливаем выбранные предметы
            var selectedItems = new List<Item>();
            int remainingWeight = capacity;

            for (int i = n; i > 0; i--)
            {
                if (dp[i, remainingWeight] != dp[i - 1, remainingWeight])
                {
                    selectedItems.Add(itemList[i - 1]);
                    remainingWeight -= itemList[i - 1].Weight;
                }
            }

            return new KnapsackResult
            {
                MaxValue = dp[n, capacity],
                SelectedItems = selectedItems
            };
        }
    }
}