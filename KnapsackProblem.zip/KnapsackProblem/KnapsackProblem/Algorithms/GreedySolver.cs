﻿using KnapsackProblem.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KnapsackProblem.Algorithms
{
    public class GreedySolver
    {
        public KnapsackResult Solve(IEnumerable<Item> items, int capacity)
        {
            // Сортируем предметы по убыванию отношения ценности к весу
            var sortedItems = items.OrderByDescending(item => item.ValuePerWeight).ToList();

            var selectedItems = new List<Item>();
            int remainingCapacity = capacity;
            int totalValue = 0;

            foreach (var item in sortedItems)
            {
                if (item.Weight <= remainingCapacity)
                {
                    selectedItems.Add(item);
                    remainingCapacity -= item.Weight;
                    totalValue += item.Value;
                }
            }

            return new KnapsackResult
            {
                MaxValue = totalValue,
                SelectedItems = selectedItems
            };
        }
    }
}