﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace ToDoListWF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Название формы
            this.Text = "To-Do List";
            this.Size = new Size(500, 400);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            
            var dateLabel = new Label
            {
                Text = "To-Do List",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };

            // Приоритет
            var priorityLabel = new Label
            {
                Text = "Приоритет:",
                Location = new Point(20, 50),
                AutoSize = true
            };

            // Выбор приоритета
            var priorityComboBox = new ComboBox
            {
                Location = new Point(100, 50),
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            priorityComboBox.Items.AddRange(new string[] { "Низкий", "Средний", "Высокий" });
            priorityComboBox.SelectedIndex = 1; // Default to "Средний"

            // Выбор даты
            var datePicker = new DateTimePicker
            {
                Location = new Point(260, 50),
                Width = 150,
                Format = DateTimePickerFormat.Short,
                Value = DateTime.Now
            };

            // Ввод задачи
            var taskTextBox = new TextBox
            {
                Location = new Point(20, 80),
                Width = 350,
                Text = "Введите задачу"  // Это будет наш placeholder
            };
            taskTextBox.ForeColor = Color.Gray;  // Делаем текст серым, как placeholder

            // Добавляем обработчики событий
            taskTextBox.Enter += (sender, e) =>
            {
                if (taskTextBox.Text == "Введите задачу")
                {
                    taskTextBox.Text = "";
                    taskTextBox.ForeColor = Color.Black;
                }
            };

            taskTextBox.Leave += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(taskTextBox.Text))
                {
                    taskTextBox.Text = "Введите задачу";
                    taskTextBox.ForeColor = Color.Gray;
                }
            };

            // Кнопка "Добавить"
            var addButton = new Button
            {
                Text = "Добавить",
                Location = new Point(380, 80),
                Width = 80
            };

            // Список задач
            var tasksLabel = new Label
            {
                Text = "Список задач:",
                Location = new Point(20, 120),
                AutoSize = true
            };

            // Создаём сетку для задач
            var tasksGridView = new DataGridView
            {
                Location = new Point(20, 150),
                Width = 440,
                Height = 150,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            // Столбцы
            tasksGridView.Columns.Add("TaskColumn", "Задача");
            tasksGridView.Columns.Add("DateColumn", "Дата");
            tasksGridView.Columns.Add("PriorityColumn", "Приоритет");

            // Кнопка удалить
            var deleteButton = new Button
            {
                Text = "Удалить выбранное",
                Location = new Point(20, 310),
                Width = 440
            };

            // Добавляем управление
            this.Controls.Add(dateLabel);
            this.Controls.Add(priorityLabel);
            this.Controls.Add(priorityComboBox);
            this.Controls.Add(datePicker);
            this.Controls.Add(taskTextBox);
            this.Controls.Add(addButton);
            this.Controls.Add(tasksLabel);
            this.Controls.Add(tasksGridView);
            this.Controls.Add(deleteButton);

            addButton.Click += (sender, e) =>
            {
                if (!string.IsNullOrWhiteSpace(taskTextBox.Text))
                {
                    tasksGridView.Rows.Add(
                        taskTextBox.Text,
                        datePicker.Value.ToString("dd.MM.yyyy"),
                        priorityComboBox.SelectedItem.ToString());
                    taskTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Пожалуйста, введите задачу", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };

            deleteButton.Click += (sender, e) =>
            {
                if (tasksGridView.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow row in tasksGridView.SelectedRows)
                    {
                        tasksGridView.Rows.Remove(row);
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста, выберите задачу для удаления", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };
        }
    }
}